from pinoybot import tag_language

# Load test data
with open("test_data.txt", "r", encoding="utf8") as f:
    sentences_tokens = [line.strip().split('|') for line in f]

with open("test_labels.txt", "r", encoding="utf8") as f:
    sentences_labels = [line.strip().split('|') for line in f]

print("=== SENTENCE-BY-SENTENCE ANALYSIS ===\n")

# Flatten for overall metrics
all_tokens = []
all_correct = []
all_pred = []

# Process each sentence
for sent_idx, (tokens, correct_labels) in enumerate(zip(sentences_tokens, sentences_labels), 1):
    print(f"{'='*80}")
    print(f"SENTENCE {sent_idx}:")
    print(f"{'='*80}")
    
    # Get predictions for this sentence
    pred_labels = tag_language(tokens)
    
    # Store for overall metrics
    all_tokens.extend(tokens)
    all_correct.extend(correct_labels)
    all_pred.extend(pred_labels)
    
    # Print each token with its prediction status
    correct_count = 0
    for i, (token, correct, pred) in enumerate(zip(tokens, correct_labels, pred_labels)):
        match_status = "✓ POSITIVE" if correct == pred else "✗ NEGATIVE"
        if correct == pred:
            correct_count += 1
        
        print(f"{i+1:3}. {token:20} | Correct: {correct:3} | Pred: {pred:3} | {match_status}")
    
    # Sentence accuracy
    accuracy = (correct_count / len(tokens)) * 100 if len(tokens) > 0 else 0
    print(f"\nSentence Accuracy: {correct_count}/{len(tokens)} ({accuracy:.2f}%)")
    print()

# Overall metrics
print("\n" + "="*80)
print("OVERALL METRICS")
print("="*80)

categories = ["ENG", "FIL", "OTH"]

TP = {c: 0 for c in categories}
FP = {c: 0 for c in categories}
FN = {c: 0 for c in categories}

# Count TP / FP / FN
for correct, pred in zip(all_correct, all_pred):
    for c in categories:
        if correct == c and pred == c:
            TP[c] += 1
        elif pred == c and correct != c:
            FP[c] += 1
        elif correct == c and pred != c:
            FN[c] += 1

# Print results
print("\n=== TP / FP / FN ===")
for c in categories:
    print(f"\n{c}:")
    print(f"  TP = {TP[c]}")
    print(f"  FP = {FP[c]}")
    print(f"  FN = {FN[c]}")
    
    # Calculate metrics
    precision = TP[c] / (TP[c] + FP[c]) if (TP[c] + FP[c]) > 0 else 0
    recall = TP[c] / (TP[c] + FN[c]) if (TP[c] + FN[c]) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    print(f"  Precision = {precision:.4f}")
    print(f"  Recall = {recall:.4f}")
    print(f"  F1-Score = {f1:.4f}")

# Overall accuracy
total_correct = sum(1 for correct, pred in zip(all_correct, all_pred) if correct == pred)
total_tokens = len(all_correct)
overall_accuracy = (total_correct / total_tokens) * 100 if total_tokens > 0 else 0

print(f"\n{'='*80}")
print(f"OVERALL ACCURACY: {total_correct}/{total_tokens} ({overall_accuracy:.2f}%)")
print(f"{'='*80}")